import React, { useState, useEffect, useRef } from "react";
import { Box, List, ListItem, Typography } from '@material-ui/core';
import { makeStyles } from "@material-ui/core/styles";
import HomeIcon from '@material-ui/icons/Home';
import StorefrontIcon from '@material-ui/icons/Storefront';
import WorkIcon from '@material-ui/icons/Work';
import CompareArrowsIcon from '@material-ui/icons/CompareArrows';
import EmojiEventsIcon from '@material-ui/icons/EmojiEvents';
import TimerIcon from '@material-ui/icons/Timer';
import { useHistory } from 'react-router-dom';
import PersonAddIcon from '@material-ui/icons/PersonAdd';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import Dice from '@material-ui/icons/Casino'
import Mine from '@material-ui/icons/Adjust';
import Upgrader from '@material-ui/icons/KeyboardCapslock';
import HelpIcon from '@material-ui/icons/Help';
import Roulette from '@material-ui/icons/AddCircle';

import Wallet from "../modals/user/WalletModal";
import Coupon from "../modals/CouponModal";
import Free from "../modals/rewards/FreeModal";
import Race from "../modals/RaceModal";
import Support from "../modals/user/SupportModal";
import Profile from "../modals/user/ProfileModal";
import LoginModal from "../modals/login/LoginModal";
import Rewards from "../modals/rewards/RewardsModal";
import Affiliates from "../modals/affiliates/AffiliatesModal";
import TermsModal from "../modals/TermsModal";
import About from "../modals/AboutModal";
import CashierModal from "../modals/cashier/CashierModal";
import RewardsModal from "../modals/rewards/RewardsModal";
import CouponModal from "../modals/CouponModal";
import FreeModal from "../modals/rewards/FreeModal";
import AffiliatesModal from "../modals/affiliates/AffiliatesModal";
import AdminModal from "../modals/admin/AdminModal";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "222px",
    backgroundColor: '#14151D',
    color: '#fff',
    fontFamily: "Poppins, sans-serif",
    padding: theme.spacing(2),
    position: "absolute",
    top: -20,
  },
  menuTitle: {
    fontFamily: "Poppins",
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: theme.spacing(1),
    marginTop: theme.spacing(2),
    letterSpacing: 4
  },
  listItem: {
    fontFamily: "Poppins",
    color: '#fff',
    fontWeight: 500,
    fontSize: 14,
    padding: theme.spacing(0.5, 1),
    textDecoration: "none",
    display: "flex",
    alignItems: "center"
  },
  icon: {
    marginRight: theme.spacing(1),
    fontSize: 20,
  },
}));

const Sidebar = ({ isMinimized }) => {
  const classes = useStyles();
  const history = useHistory();

  const [openGames, setOpenGames] = useState(false);
  const [openProfile, setOpenProfile] = useState(false);
  const [openProfileMobile, setOpenProfileMobile] = useState(false);
  const [openCashier, setOpenCashier] = useState(false);
  const [openLogin, setOpenLogin] = useState(false);
  const [openRewards, setOpenRewards] = useState(false);
  const [openCoupon, setOpenCoupon] = useState(false);
  const [openFree, setOpenFree] = useState(false);
  const [openAffiliates, setOpenAffiliates] = useState(false);
  const [openSupport, setOpenSupport] = useState(false);
  const [openTerms, setOpenTerms] = useState(false);
  const [openAdmin, setOpenAdmin] = useState(false);

  return (
    <Box className={classes.root}>
      <RewardsModal open={openRewards} handleClose={() => setOpenRewards(!openRewards)}/>
      <AffiliatesModal open={openAffiliates} handleClose={() => setOpenAffiliates(!openAffiliates)}/>
      <Support open={openSupport} handleClose={() => setOpenSupport(!openSupport)}/>

      {!isMinimized ? (
        <>
        <Typography variant="h6" className={classes.menuTitle}>MENU</Typography>
        <List>
          <a href="/home" button className={classes.listItem}>
            <HomeIcon className={classes.icon} />
            Home
          </a>
          <a href="/marketplace" button className={classes.listItem}>
            <StorefrontIcon className={classes.icon} />
            Marketplace
          </a>
        </List>
        
        <Typography variant="h6" className={classes.menuTitle}>GAMES</Typography>
        <List>
          <a href="/cases" button className={classes.listItem}>
            <svg width="24" className={classes.icon} height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3.7597 12.3807L12.1719 13.5L20.5841 12.5L20.5841 18.7112C20.5841 21.0991 20.5841 22.2917 19.8799 23.0337C19.1757 23.7756 18.0436 23.7756 15.7772 23.7756H8.56668C6.30019 23.7756 5.16815 23.7756 4.46392 23.0337C3.7597 22.2917 3.7597 21.0991 3.7597 18.7112L3.7597 12.3807ZM1.13389 9.61421L3.7597 12.3807L8.84984 7.5L5.66927 5.28033C5.46225 5.13511 5.21757 5.06115 4.96896 5.06863C4.72035 5.07612 4.48007 5.16468 4.28126 5.32211L1.26247 7.70619C1.12476 7.81504 1.01086 7.95379 0.928468 8.11305C0.84608 8.27231 0.797132 8.44836 0.784939 8.62928C0.772746 8.81021 0.797593 8.99178 0.857796 9.16171C0.917999 9.33163 1.01215 9.48595 1.13389 9.61421ZM23.21 9.61421L20.5841 12.3807L15.494 7.5L18.6746 5.28033C18.8816 5.13511 19.1263 5.06115 19.3749 5.06863C19.6235 5.07612 19.8638 5.16468 20.0626 5.32211L23.0814 7.70619C23.2191 7.81504 23.333 7.95379 23.4154 8.11305C23.4978 8.27231 23.5467 8.44836 23.5589 8.62928C23.5711 8.81021 23.5463 8.99178 23.486 9.16171C23.4258 9.33163 23.3317 9.48595 23.21 9.61421Z" fill="white"/>
                  <path d="M19.3825 12.3806V13.6467H4.96155V12.3806L8.37528 8.5H15.494L19.3825 12.3806Z" stroke="white" stroke-width="2" stroke-linecap="round"/>
                  <g filter="url(#filter0_f_587_476)">
                  <path d="M20.7145 1L17.7088 12H6.54482L2.68036 1H3.60519H20.7145Z" fill="url(#paint0_linear_587_476)"/>
                  </g>
                  <path d="M19.2653 12.5V16.5H5.07867V12.5H19.2653Z" fill="white" stroke="white" stroke-linecap="round"/>
                  <path d="M4.1041 13.5L3.62952 12H4.1041V13.5Z" fill="white"/>
                  <path d="M20.2398 14L20.7144 12H20.2398V14Z" fill="white"/>
                  <defs>
                  <filter id="filter0_f_587_476" x="2.48036" y="0.8" width="18.4342" height="11.4" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                  <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                  <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                  <feGaussianBlur stdDeviation="0.1" result="effect1_foregroundBlur_587_476"/>
                  </filter>
                  <linearGradient id="paint0_linear_587_476" x1="11.6974" y1="1" x2="11.6974" y2="12.5238" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#801CFF" stop-opacity="0"/>
                  <stop offset="1" stop-color="#801CFF"/>
                  </linearGradient>
                  </defs>
            </svg>
            Cases
          </a>
          <a href="/battles" button className={classes.listItem}>
            <svg width="20" className={classes.icon} height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.8214 18.715L14.3962 16.3105C14.2007 16.1167 13.8853 16.1174 13.6906 16.312L12.3062 17.6964C12.1109 17.8917 11.7943 17.8917 11.5991 17.6964L11.2876 17.385C10.9235 17.0208 10.7414 16.5696 10.7414 16.0312C10.7414 15.4929 10.9235 15.0417 11.2876 14.6775L15.3014 10.6638C15.6655 10.2996 16.1168 10.1175 16.6551 10.1175C17.1935 10.1175 17.6447 10.2996 18.0089 10.6638L18.3203 10.9752C18.5156 11.1705 18.5156 11.487 18.3203 11.6823L16.9359 13.0667C16.7412 13.2614 16.7406 13.5768 16.9344 13.7723L19.3389 16.1975C19.5289 16.3875 19.6239 16.6092 19.6239 16.8625C19.6239 17.1158 19.5289 17.3375 19.3389 17.5275L18.1514 18.715C17.9614 18.905 17.7397 19 17.4864 19C17.233 19 17.0114 18.905 16.8214 18.715ZM19.6239 3.59289C19.6239 3.7255 19.5712 3.85268 19.4774 3.94645L8.9489 14.475C8.89154 14.5323 8.89677 14.6268 8.96012 14.6775C9.32429 15.0417 9.50637 15.4929 9.50637 16.0312C9.50637 16.5696 9.32429 17.0208 8.96012 17.385L8.64867 17.6964C8.45341 17.8917 8.13683 17.8917 7.94157 17.6964L6.55716 16.312C6.36249 16.1174 6.04708 16.1167 5.85157 16.3105L3.42637 18.715C3.23637 18.905 3.0147 19 2.76137 19C2.50804 19 2.28637 18.905 2.09637 18.715L0.908871 17.5275C0.718871 17.3375 0.623871 17.1158 0.623871 16.8625C0.623871 16.6092 0.718871 16.3875 0.908871 16.1975L3.31335 13.7723C3.50718 13.5768 3.5065 13.2614 3.31183 13.0667L1.92742 11.6823C1.73216 11.487 1.73216 11.1705 1.92742 10.9752L2.23887 10.6638C2.60304 10.2996 3.05429 10.1175 3.59262 10.1175C4.13095 10.1175 4.5822 10.2996 4.94637 10.6638C4.99705 10.7271 5.09154 10.7323 5.1489 10.675L15.6774 0.146447C15.7712 0.0526783 15.8984 0 16.031 0H19.1239C19.4 0 19.6239 0.223858 19.6239 0.5V3.59289ZM5.67992 8.14895C5.48466 8.34421 5.16808 8.34421 4.97282 8.14895L0.770317 3.94645C0.676549 3.85268 0.623871 3.7255 0.623871 3.59289V0.5C0.623871 0.223857 0.847728 0 1.12387 0H4.21676C4.34937 0 4.47655 0.0526784 4.57032 0.146447L8.77282 4.34895C8.96808 4.54421 8.96808 4.86079 8.77282 5.05605L5.67992 8.14895Z" fill="#F8F8F8"/></svg>
            Case Battles
          </a>
          <a href="/Dice" button className={classes.listItem}>
            <svg width="18" className={classes.icon} height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.05078 0.251757C8.33926 0.0868409 8.6667 0 9.00004 0C9.33338 0 9.66082 0.0868409 9.9493 0.251757L17.0546 4.31384C17.3421 4.47821 17.5808 4.71436 17.7468 4.99859C17.9127 5.28282 18.0001 5.60515 18 5.93324V14.0668C17.9999 14.3947 17.9125 14.7168 17.7465 15.0009C17.5806 15.2849 17.342 15.5209 17.0546 15.6852L9.9493 19.7482C9.66082 19.9132 9.33338 20 9.00004 20C8.6667 20 8.33926 19.9132 8.05078 19.7482L0.945512 15.6862C0.657974 15.5218 0.41926 15.2856 0.253313 15.0014C0.087366 14.7172 2.06352e-05 14.3948 3.81496e-05 14.0668V5.93324C0.000186703 5.60531 0.0876107 5.28318 0.253549 4.99912C0.419488 4.71507 0.658113 4.47907 0.945512 4.31477L8.05078 0.251757ZM2.6053 6.34394C2.53327 6.30265 2.45149 6.28085 2.3682 6.28073C2.28491 6.28061 2.20306 6.30218 2.13091 6.34326C2.05876 6.38434 1.99885 6.44348 1.95722 6.51472C1.9156 6.58596 1.89373 6.66678 1.89383 6.74903V12.9881C1.89398 13.316 1.9814 13.6382 2.14734 13.9222C2.31328 14.2063 2.5519 14.4423 2.8393 14.6066L8.28762 17.7219C8.35958 17.7631 8.44128 17.7849 8.52448 17.7851C8.60769 17.7852 8.68947 17.7638 8.7616 17.7228C8.83372 17.6818 8.89365 17.6228 8.93534 17.5517C8.97703 17.4806 8.99902 17.3999 8.99909 17.3177V11.0787C8.99894 10.7507 8.91152 10.4286 8.74558 10.1445C8.57964 9.86049 8.34102 9.62449 8.05362 9.4602L2.6053 6.34394ZM12.5688 3.93495C12.1159 3.67674 11.3808 3.67674 10.9279 3.93495C10.4751 4.19315 10.4751 4.61227 10.9279 4.87048C11.3808 5.12868 12.1159 5.12868 12.5688 4.87048C13.0216 4.61227 13.0216 4.19315 12.5688 3.93495ZM7.07404 3.93495C6.6212 3.67674 5.88604 3.67674 5.4332 3.93495C4.98035 4.19315 4.98035 4.61227 5.4332 4.87048C5.88604 5.12868 6.6212 5.12868 7.07404 4.87048C7.52783 4.61227 7.52783 4.19315 7.07404 3.93495ZM13.7293 13.5971C14.2949 13.2744 14.7544 12.4894 14.7544 11.843C14.7544 11.1975 14.2949 10.9355 13.7293 11.2583C13.1628 11.581 12.7033 12.3669 12.7033 13.0124C12.7033 13.6579 13.1637 13.9199 13.7293 13.5971ZM3.66162 10.1871C4.11446 10.4462 4.48204 10.2367 4.48204 9.71934C4.48204 9.20293 4.11446 8.57518 3.66162 8.31604C3.20878 8.05783 2.8412 8.26739 2.8412 8.78381C2.8412 9.30116 3.20878 9.9289 3.66162 10.1871ZM7.76372 15.3307C7.76372 15.8471 7.3952 16.0566 6.94235 15.7984C6.48951 15.5402 6.12193 14.9115 6.12193 14.3951C6.12193 13.8787 6.48951 13.6692 6.94235 13.9274C7.3952 14.1856 7.76372 14.8142 7.76372 15.3307ZM4.48204 13.4615C4.48204 13.9788 4.11446 14.1884 3.66162 13.9292C3.20878 13.671 2.8412 13.0433 2.8412 12.5259C2.8412 12.0095 3.20878 11.8 3.66162 12.0582C4.11446 12.3173 4.48204 12.9451 4.48204 13.4615ZM7.76278 11.5904C7.76278 12.1078 7.3952 12.3173 6.94235 12.0582C6.48856 11.8009 6.12193 11.1722 6.12193 10.6549C6.12193 10.1394 6.48856 9.92983 6.94235 10.1871C7.3952 10.4462 7.76278 11.0749 7.76278 11.5904Z" fill="#F8F8F8"/></svg>
            Dice
          </a>
          <a href="/upgrader" button className={classes.listItem}>
          <svg className={classes.icon} style={{ width: 20, height: 20 }} width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.25107 10.1209C6.11967 10.2148 6.04169 10.3663 6.04169 10.5278V14.7364C6.04169 15.1431 6.50137 15.3797 6.83231 15.1433L14.2094 9.87393C14.3833 9.74975 14.6168 9.74975 14.7906 9.87393L22.1677 15.1433C22.4987 15.3797 22.9584 15.1431 22.9584 14.7364V10.5278C22.9584 10.3663 22.8804 10.2148 22.749 10.1209L14.7906 4.43643C14.6168 4.31225 14.3832 4.31225 14.2094 4.43643L6.25107 10.1209Z" fill="#F8F8F8"/>
                <path d="M6.25107 18.5794C6.11967 18.6733 6.04169 18.8248 6.04169 18.9863V23.1949C6.04169 23.6016 6.50137 23.8382 6.83231 23.6018L14.2094 18.3324C14.3833 18.2082 14.6168 18.2082 14.7906 18.3324L22.1677 23.6018C22.4987 23.8382 22.9584 23.6016 22.9584 23.1949V18.9863C22.9584 18.8248 22.8804 18.6733 22.749 18.5794L14.7906 12.8949C14.6168 12.7707 14.3832 12.7707 14.2094 12.8949L6.25107 18.5794Z" fill="#F8F8F8"/>
                </svg>
            Upgrader
          </a>
          <a href="/mines" button className={classes.listItem}>
            <svg className={classes.icon} width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.28958 21.8501C5.29305 21.8501 3.59616 21.1435 2.19892 19.7303C0.801665 18.317 0.102721 16.6118 0.102082 14.6147C0.101443 12.6175 0.792401 10.9283 2.17496 9.54701C3.55751 8.16574 5.24642 7.4751 7.24167 7.4751H7.55312L8.2 6.34906C8.39167 5.99767 8.67916 5.77022 9.0625 5.66672C9.44583 5.56322 9.81319 5.61497 10.1646 5.82197L10.8833 6.22926L11.0031 6.0376C11.3705 5.35079 11.9455 4.90357 12.7281 4.69593C13.5108 4.48829 14.2455 4.58413 14.9323 4.98343L15.7708 5.4626L14.8125 7.11572L13.974 6.63656C13.7503 6.50878 13.5066 6.48067 13.2427 6.55222C12.9789 6.62378 12.7834 6.77168 12.6562 6.99593L12.5365 7.1876L13.4948 7.73864C13.8302 7.93031 14.05 8.21781 14.1541 8.60114C14.2583 8.98447 14.2142 9.34385 14.0219 9.67926L13.375 10.8293C13.7424 11.4043 14.018 12.0154 14.202 12.6626C14.386 13.3098 14.4777 13.9764 14.4771 14.6626C14.4771 16.6591 13.7785 18.3563 12.3812 19.7542C10.984 21.1521 9.28675 21.8507 7.28958 21.8501ZM18.1667 8.43343V6.51676H21.0417V8.43343H18.1667ZM12.8958 3.1626V0.287598H14.8125V3.1626H12.8958ZM17.5677 5.10322L16.226 3.76156L18.2625 1.7251L19.6042 3.06676L17.5677 5.10322Z" fill="#F8F8F8"/>
            </svg>
            Mines
          </a>
          <a href="/roulette" button className={classes.listItem}>
            <Roulette className={classes.icon} />
            Roulette
          </a>
        </List>
        
        <Typography variant="h6" className={classes.menuTitle}>EARN</Typography>
        <List>
          <ListItem button className={classes.listItem} onClick={() => setOpenRewards(!openRewards)}>
            <EmojiEventsIcon className={classes.icon} />
            Level Rewards
          </ListItem>
          <ListItem button className={classes.listItem}>
            <TimerIcon className={classes.icon} />
            Weekly race
          </ListItem>
          <ListItem button className={classes.listItem} onClick={() => setOpenAffiliates(!openAffiliates)}>
            <PersonAddIcon className={classes.icon} />
            Refer a friend
          </ListItem>
        </List>
        
        <Typography variant="h6" className={classes.menuTitle}>MARKETPLACE</Typography>
        <List>
          <a href="/shop" button className={classes.listItem}>
            <ShoppingCartIcon className={classes.icon} />
            Shop
          </a>
          <a button className={classes.listItem} onClick={() => setOpenSupport(!openSupport)}>
            <HelpIcon className={classes.icon} />
            Support
          </a>
        </List>
      </>
      ) : (
        <>
          <List style={{display: "flex",
            alignItems: "center",
            flexDirection: "column",
            marginTop: 40,
            gap: "10px"
          }}>
            <a href="/home" button className={classes.listItem}>
              <HomeIcon className={classes.icon} />
            </a>
            <a href="/marketplace" button className={classes.listItem}>
              <StorefrontIcon className={classes.icon} />
            </a>
            <a href="/cases" button className={classes.listItem}>
              <svg width="24" className={classes.icon} height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.7597 12.3807L12.1719 13.5L20.5841 12.5L20.5841 18.7112C20.5841 21.0991 20.5841 22.2917 19.8799 23.0337C19.1757 23.7756 18.0436 23.7756 15.7772 23.7756H8.56668C6.30019 23.7756 5.16815 23.7756 4.46392 23.0337C3.7597 22.2917 3.7597 21.0991 3.7597 18.7112L3.7597 12.3807ZM1.13389 9.61421L3.7597 12.3807L8.84984 7.5L5.66927 5.28033C5.46225 5.13511 5.21757 5.06115 4.96896 5.06863C4.72035 5.07612 4.48007 5.16468 4.28126 5.32211L1.26247 7.70619C1.12476 7.81504 1.01086 7.95379 0.928468 8.11305C0.84608 8.27231 0.797132 8.44836 0.784939 8.62928C0.772746 8.81021 0.797593 8.99178 0.857796 9.16171C0.917999 9.33163 1.01215 9.48595 1.13389 9.61421ZM23.21 9.61421L20.5841 12.3807L15.494 7.5L18.6746 5.28033C18.8816 5.13511 19.1263 5.06115 19.3749 5.06863C19.6235 5.07612 19.8638 5.16468 20.0626 5.32211L23.0814 7.70619C23.2191 7.81504 23.333 7.95379 23.4154 8.11305C23.4978 8.27231 23.5467 8.44836 23.5589 8.62928C23.5711 8.81021 23.5463 8.99178 23.486 9.16171C23.4258 9.33163 23.3317 9.48595 23.21 9.61421Z" fill="white"/>
                    <path d="M19.3825 12.3806V13.6467H4.96155V12.3806L8.37528 8.5H15.494L19.3825 12.3806Z" stroke="white" stroke-width="2" stroke-linecap="round"/>
                    <g filter="url(#filter0_f_587_476)">
                    <path d="M20.7145 1L17.7088 12H6.54482L2.68036 1H3.60519H20.7145Z" fill="url(#paint0_linear_587_476)"/>
                    </g>
                    <path d="M19.2653 12.5V16.5H5.07867V12.5H19.2653Z" fill="white" stroke="white" stroke-linecap="round"/>
                    <path d="M4.1041 13.5L3.62952 12H4.1041V13.5Z" fill="white"/>
                    <path d="M20.2398 14L20.7144 12H20.2398V14Z" fill="white"/>
                    <defs>
                    <filter id="filter0_f_587_476" x="2.48036" y="0.8" width="18.4342" height="11.4" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
                    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
                    <feGaussianBlur stdDeviation="0.1" result="effect1_foregroundBlur_587_476"/>
                    </filter>
                    <linearGradient id="paint0_linear_587_476" x1="11.6974" y1="1" x2="11.6974" y2="12.5238" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#801CFF" stop-opacity="0"/>
                    <stop offset="1" stop-color="#801CFF"/>
                    </linearGradient>
                    </defs>
              </svg>
            </a>
            <a href="/battles" button className={classes.listItem}>
              <svg width="20" className={classes.icon} height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.8214 18.715L14.3962 16.3105C14.2007 16.1167 13.8853 16.1174 13.6906 16.312L12.3062 17.6964C12.1109 17.8917 11.7943 17.8917 11.5991 17.6964L11.2876 17.385C10.9235 17.0208 10.7414 16.5696 10.7414 16.0312C10.7414 15.4929 10.9235 15.0417 11.2876 14.6775L15.3014 10.6638C15.6655 10.2996 16.1168 10.1175 16.6551 10.1175C17.1935 10.1175 17.6447 10.2996 18.0089 10.6638L18.3203 10.9752C18.5156 11.1705 18.5156 11.487 18.3203 11.6823L16.9359 13.0667C16.7412 13.2614 16.7406 13.5768 16.9344 13.7723L19.3389 16.1975C19.5289 16.3875 19.6239 16.6092 19.6239 16.8625C19.6239 17.1158 19.5289 17.3375 19.3389 17.5275L18.1514 18.715C17.9614 18.905 17.7397 19 17.4864 19C17.233 19 17.0114 18.905 16.8214 18.715ZM19.6239 3.59289C19.6239 3.7255 19.5712 3.85268 19.4774 3.94645L8.9489 14.475C8.89154 14.5323 8.89677 14.6268 8.96012 14.6775C9.32429 15.0417 9.50637 15.4929 9.50637 16.0312C9.50637 16.5696 9.32429 17.0208 8.96012 17.385L8.64867 17.6964C8.45341 17.8917 8.13683 17.8917 7.94157 17.6964L6.55716 16.312C6.36249 16.1174 6.04708 16.1167 5.85157 16.3105L3.42637 18.715C3.23637 18.905 3.0147 19 2.76137 19C2.50804 19 2.28637 18.905 2.09637 18.715L0.908871 17.5275C0.718871 17.3375 0.623871 17.1158 0.623871 16.8625C0.623871 16.6092 0.718871 16.3875 0.908871 16.1975L3.31335 13.7723C3.50718 13.5768 3.5065 13.2614 3.31183 13.0667L1.92742 11.6823C1.73216 11.487 1.73216 11.1705 1.92742 10.9752L2.23887 10.6638C2.60304 10.2996 3.05429 10.1175 3.59262 10.1175C4.13095 10.1175 4.5822 10.2996 4.94637 10.6638C4.99705 10.7271 5.09154 10.7323 5.1489 10.675L15.6774 0.146447C15.7712 0.0526783 15.8984 0 16.031 0H19.1239C19.4 0 19.6239 0.223858 19.6239 0.5V3.59289ZM5.67992 8.14895C5.48466 8.34421 5.16808 8.34421 4.97282 8.14895L0.770317 3.94645C0.676549 3.85268 0.623871 3.7255 0.623871 3.59289V0.5C0.623871 0.223857 0.847728 0 1.12387 0H4.21676C4.34937 0 4.47655 0.0526784 4.57032 0.146447L8.77282 4.34895C8.96808 4.54421 8.96808 4.86079 8.77282 5.05605L5.67992 8.14895Z" fill="#F8F8F8"/></svg>
            </a>
            <a href="/Dice" button className={classes.listItem}>
              <svg width="18" className={classes.icon} height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.05078 0.251757C8.33926 0.0868409 8.6667 0 9.00004 0C9.33338 0 9.66082 0.0868409 9.9493 0.251757L17.0546 4.31384C17.3421 4.47821 17.5808 4.71436 17.7468 4.99859C17.9127 5.28282 18.0001 5.60515 18 5.93324V14.0668C17.9999 14.3947 17.9125 14.7168 17.7465 15.0009C17.5806 15.2849 17.342 15.5209 17.0546 15.6852L9.9493 19.7482C9.66082 19.9132 9.33338 20 9.00004 20C8.6667 20 8.33926 19.9132 8.05078 19.7482L0.945512 15.6862C0.657974 15.5218 0.41926 15.2856 0.253313 15.0014C0.087366 14.7172 2.06352e-05 14.3948 3.81496e-05 14.0668V5.93324C0.000186703 5.60531 0.0876107 5.28318 0.253549 4.99912C0.419488 4.71507 0.658113 4.47907 0.945512 4.31477L8.05078 0.251757ZM2.6053 6.34394C2.53327 6.30265 2.45149 6.28085 2.3682 6.28073C2.28491 6.28061 2.20306 6.30218 2.13091 6.34326C2.05876 6.38434 1.99885 6.44348 1.95722 6.51472C1.9156 6.58596 1.89373 6.66678 1.89383 6.74903V12.9881C1.89398 13.316 1.9814 13.6382 2.14734 13.9222C2.31328 14.2063 2.5519 14.4423 2.8393 14.6066L8.28762 17.7219C8.35958 17.7631 8.44128 17.7849 8.52448 17.7851C8.60769 17.7852 8.68947 17.7638 8.7616 17.7228C8.83372 17.6818 8.89365 17.6228 8.93534 17.5517C8.97703 17.4806 8.99902 17.3999 8.99909 17.3177V11.0787C8.99894 10.7507 8.91152 10.4286 8.74558 10.1445C8.57964 9.86049 8.34102 9.62449 8.05362 9.4602L2.6053 6.34394ZM12.5688 3.93495C12.1159 3.67674 11.3808 3.67674 10.9279 3.93495C10.4751 4.19315 10.4751 4.61227 10.9279 4.87048C11.3808 5.12868 12.1159 5.12868 12.5688 4.87048C13.0216 4.61227 13.0216 4.19315 12.5688 3.93495ZM7.07404 3.93495C6.6212 3.67674 5.88604 3.67674 5.4332 3.93495C4.98035 4.19315 4.98035 4.61227 5.4332 4.87048C5.88604 5.12868 6.6212 5.12868 7.07404 4.87048C7.52783 4.61227 7.52783 4.19315 7.07404 3.93495ZM13.7293 13.5971C14.2949 13.2744 14.7544 12.4894 14.7544 11.843C14.7544 11.1975 14.2949 10.9355 13.7293 11.2583C13.1628 11.581 12.7033 12.3669 12.7033 13.0124C12.7033 13.6579 13.1637 13.9199 13.7293 13.5971ZM3.66162 10.1871C4.11446 10.4462 4.48204 10.2367 4.48204 9.71934C4.48204 9.20293 4.11446 8.57518 3.66162 8.31604C3.20878 8.05783 2.8412 8.26739 2.8412 8.78381C2.8412 9.30116 3.20878 9.9289 3.66162 10.1871ZM7.76372 15.3307C7.76372 15.8471 7.3952 16.0566 6.94235 15.7984C6.48951 15.5402 6.12193 14.9115 6.12193 14.3951C6.12193 13.8787 6.48951 13.6692 6.94235 13.9274C7.3952 14.1856 7.76372 14.8142 7.76372 15.3307ZM4.48204 13.4615C4.48204 13.9788 4.11446 14.1884 3.66162 13.9292C3.20878 13.671 2.8412 13.0433 2.8412 12.5259C2.8412 12.0095 3.20878 11.8 3.66162 12.0582C4.11446 12.3173 4.48204 12.9451 4.48204 13.4615ZM7.76278 11.5904C7.76278 12.1078 7.3952 12.3173 6.94235 12.0582C6.48856 11.8009 6.12193 11.1722 6.12193 10.6549C6.12193 10.1394 6.48856 9.92983 6.94235 10.1871C7.3952 10.4462 7.76278 11.0749 7.76278 11.5904Z" fill="#F8F8F8"/></svg>
            </a>
            <a href="/upgrader" button className={classes.listItem}>
            <svg className={classes.icon} style={{ width: 20, height: 20 }} width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6.25107 10.1209C6.11967 10.2148 6.04169 10.3663 6.04169 10.5278V14.7364C6.04169 15.1431 6.50137 15.3797 6.83231 15.1433L14.2094 9.87393C14.3833 9.74975 14.6168 9.74975 14.7906 9.87393L22.1677 15.1433C22.4987 15.3797 22.9584 15.1431 22.9584 14.7364V10.5278C22.9584 10.3663 22.8804 10.2148 22.749 10.1209L14.7906 4.43643C14.6168 4.31225 14.3832 4.31225 14.2094 4.43643L6.25107 10.1209Z" fill="#F8F8F8"/>
                  <path d="M6.25107 18.5794C6.11967 18.6733 6.04169 18.8248 6.04169 18.9863V23.1949C6.04169 23.6016 6.50137 23.8382 6.83231 23.6018L14.2094 18.3324C14.3833 18.2082 14.6168 18.2082 14.7906 18.3324L22.1677 23.6018C22.4987 23.8382 22.9584 23.6016 22.9584 23.1949V18.9863C22.9584 18.8248 22.8804 18.6733 22.749 18.5794L14.7906 12.8949C14.6168 12.7707 14.3832 12.7707 14.2094 12.8949L6.25107 18.5794Z" fill="#F8F8F8"/>
                  </svg>
            </a>
            <a href="/mines" button className={classes.listItem}>
              <svg className={classes.icon} width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.28958 21.8501C5.29305 21.8501 3.59616 21.1435 2.19892 19.7303C0.801665 18.317 0.102721 16.6118 0.102082 14.6147C0.101443 12.6175 0.792401 10.9283 2.17496 9.54701C3.55751 8.16574 5.24642 7.4751 7.24167 7.4751H7.55312L8.2 6.34906C8.39167 5.99767 8.67916 5.77022 9.0625 5.66672C9.44583 5.56322 9.81319 5.61497 10.1646 5.82197L10.8833 6.22926L11.0031 6.0376C11.3705 5.35079 11.9455 4.90357 12.7281 4.69593C13.5108 4.48829 14.2455 4.58413 14.9323 4.98343L15.7708 5.4626L14.8125 7.11572L13.974 6.63656C13.7503 6.50878 13.5066 6.48067 13.2427 6.55222C12.9789 6.62378 12.7834 6.77168 12.6562 6.99593L12.5365 7.1876L13.4948 7.73864C13.8302 7.93031 14.05 8.21781 14.1541 8.60114C14.2583 8.98447 14.2142 9.34385 14.0219 9.67926L13.375 10.8293C13.7424 11.4043 14.018 12.0154 14.202 12.6626C14.386 13.3098 14.4777 13.9764 14.4771 14.6626C14.4771 16.6591 13.7785 18.3563 12.3812 19.7542C10.984 21.1521 9.28675 21.8507 7.28958 21.8501ZM18.1667 8.43343V6.51676H21.0417V8.43343H18.1667ZM12.8958 3.1626V0.287598H14.8125V3.1626H12.8958ZM17.5677 5.10322L16.226 3.76156L18.2625 1.7251L19.6042 3.06676L17.5677 5.10322Z" fill="#F8F8F8"/>
              </svg>
            </a>
            <a href="/roulette" button className={classes.listItem}>
              <Roulette className={classes.icon} />
            </a>
            <a button className={classes.listItem} onClick={() => setOpenRewards(!openRewards)}>
            <EmojiEventsIcon className={classes.icon} />
            </a>
            <a button className={classes.listItem}>
              <TimerIcon className={classes.icon} />
            </a>
            <a button className={classes.listItem} onClick={() => setOpenAffiliates(!openAffiliates)}>
              <PersonAddIcon className={classes.icon} />
            </a>
            <a href="/shop" button className={classes.listItem}>
            <ShoppingCartIcon className={classes.icon} />
          </a>
          <a button className={classes.listItem} onClick={() => setOpenSupport(!openSupport)}>
            <HelpIcon className={classes.icon} />
          </a>
          </List>
        </>
      )}
    </Box>
  );
};

export default Sidebar;