import { combineReducers } from "redux";

// Import external reducers
import auth from "./auth";

export default combineReducers({
  auth,
});